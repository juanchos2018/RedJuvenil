const link = {
  agency: {
    home: '/',
    contact: '/contact'
  }
}

export default link
